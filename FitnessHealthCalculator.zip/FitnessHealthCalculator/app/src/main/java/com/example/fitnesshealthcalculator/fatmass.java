package com.example.fitnesshealthcalculator;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class fatmass extends AppCompatActivity {
    Button btn;
    EditText height,weight,age;
    TextView result;
    TextView result2;
    TextView result3;
    LinearLayout malelayout,femalelayout;
    ImageView mimg,fimg;
    double h=0,w=0,a=0,fm=0,bf=0,lm=0,h1=0;
    String user="0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fatmass);
        btn = findViewById(R.id.btncal);
        height = findViewById(R.id.heighttxt);
        weight = findViewById(R.id.weighttxt);
        age = findViewById(R.id.agetxt);
        result = findViewById(R.id.result);
        result2 = findViewById(R.id.result2);
        result3 = findViewById(R.id.result3);
        malelayout = findViewById(R.id.male);
        femalelayout = findViewById(R.id.female);
        mimg = findViewById(R.id.maleimg);
        fimg = findViewById(R.id.femaleimg);

        malelayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mimg.setColorFilter(getResources().getColor(R.color.green));
                fimg.setColorFilter(getResources().getColor(R.color.grey));
                user = "Male";

            }
        });
        femalelayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fimg.setColorFilter(getResources().getColor(R.color.green));
                mimg.setColorFilter(getResources().getColor(R.color.grey));
                user = "Female";

            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1=height.getText().toString();
                String str2=weight.getText().toString();
                String str3=age.getText().toString();
                if (user.equals("0")){
                    Toast.makeText(com.example.fitnesshealthcalculator.fatmass.this,"Select Your Gender",Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(str1)){
                    height.setError("Select Height");
                    height.requestFocus();
                    return;
                }
                else if (TextUtils.isEmpty(str2)){
                    weight.setError("Select Weight");
                    weight.requestFocus();
                    return;
                }
                else if (TextUtils.isEmpty(str3)){
                    age.setError("Select Age");
                    age.requestFocus();
                    return;
                }
                else {
                    calculate();
                }

            }
        });
    }

    private void calculate(){
        h=Double.parseDouble(height.getText().toString());
        w=Double.parseDouble(weight.getText().toString());
        a=Double.parseDouble(age.getText().toString());
        if (user.equals("Male")){
//            bmr=((10*w)+(6.25*h)-(5*a)+5);
            h1=h*0.01;
            fm=Math.round((1.20 * (w/(h1*h1)))+(0.23*a)-16.2);
            bf=(fm*w)/100;
            lm=Math.round((0.407 * w) + (0.267 * h) -19.2);
            result.setText(Double.toString(fm));
            result2.setText(Double.toString(bf));
            result3.setText(Double.toString(lm));
        }
        if (user.equals("Female")){
//            bmr=((10*w)+(6.25*h)-(5*a)+161);
            h1=h*0.01;
            fm=Math.round((1.20 * (w/(h1*h1)))+(0.23*a)-16.2);
            bf=((fm*w)/100);
            lm=Math.round((0.252 * w) + (0.473 * h)-48.3);
            result.setText(Double.toString(fm));
            result2.setText(Double.toString(bf));
            result3.setText(Double.toString(lm));
        }

    }



}